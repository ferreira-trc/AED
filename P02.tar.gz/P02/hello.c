/*
** Tomás Oliveira e Silva, AED, October 2021
**
** my first C program
*/

#include <stdio.h>

int main(void)
{
  puts("Hello world!");
  return 0;
}
