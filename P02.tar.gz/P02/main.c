//
// Tomás Oliveira e Silva, AED, October 2021
//
// code to print the sizes (in bytes) of the fundamental data types -- the program entry point (main() function)
//
// the file sizes.h contains the prototype of the function print_sizes()
// the file sizes.c contains the function print_sizes()
//

#include "sizes.h"

int main(void)
{
  print_sizes();
  return 0;
}
